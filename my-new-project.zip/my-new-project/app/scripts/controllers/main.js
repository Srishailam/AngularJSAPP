'use strict';

/**
 * @ngdoc function
 * @name sampleAppApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the sampleAppApp
 */
angular.module('sampleAppApp')
  .controller('MainCtrl', ['$scope','SimpleFactory',function ($scope,SimpleFactory) {
    $scope.showErrorMsg = false;
    var promise = SimpleFactory.getItems();
    promise.then(
      function(response){
        $scope.items = response.data;
      },
  
      function(error){
        $scope.showErrorMsg = true;
        console.log(error);
      }
    );
  }]);
