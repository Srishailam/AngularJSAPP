'use strict';
angular.module('sampleAppApp')
.factory('SimpleFactory', ['$http',function($http){
    function getItems(){
        return $http.get('https://jsonplaceholder.typicode.com/posts');
    }
    var obj = {
        getItems:getItems
    };
    return obj;
}])
.service('SampleService', ['$http',function($http){
    this.getItems = function(){
        return $http.get('https://jsonplaceholder.typicode.com/posts');
    };
}]);